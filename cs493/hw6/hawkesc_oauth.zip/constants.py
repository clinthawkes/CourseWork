base_url = "https://hw6-hawkesc.wl.r.appspot.com"
#base_url = "http://127.0.0.1:8080"
clientId = "560385624589-9kdg90vgqf7um6pemgfmqpqnsioc1bgi.apps.googleusercontent.com"
clientSecret = "PGiCPrntIPCWsapz731iTBcc"
redirectURL = base_url + "/oauth"
scope = "https://www.googleapis.com/auth/userinfo.profile"
entityId = 5680529164730368