boats = "boats"
base_url = "https://hw5-hawkesc.wl.r.appspot.com"
#base_url = "http://127.0.0.1:8080"
boats_url = base_url + "/boats/"
