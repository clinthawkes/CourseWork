boats = "boats"
slips = "slips"
boats_url = "http://hw3-hawkesc.wl.r.appspot.com/boats/"
slips_url = "http://hw3-hawkesc.wl.r.appspot.com/slips/"
