from flask import Flask, flash, render_template, url_for
from flask import request, redirect
from db_connector.db_connector import connect_to_database, execute_query

webapp = Flask(__name__)
webapp.secret_key = 'Thou shall not pass'

@webapp.route('/')
def index():
    return render_template('index.html')


@webapp.route('/books', methods=['POST', 'GET'])
def viewBooks():
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT publisherID, companyName FROM publisher'
        res1 = execute_query(db_connection, query).fetchall();
        query2 = 'SELECT facilityID, branch FROM facility'
        res2 = execute_query(db_connection, query2).fetchall();
        query3 = 'SELECT ISBN, title, companyName, branch FROM book JOIN publisher ON publisher.publisherID = book.publisher LEFT JOIN facility ON facility.facilityID = book.location'
        res3 = execute_query(db_connection, query3).fetchall();

        return render_template('books.html', publishers = res1, locations = res2, books = res3)
    elif request.method == 'POST':
        ISBN = request.form['ISBN']
        title = request.form['title']
        publisher = request.form['publisher']
        location = request.form['location']
        print('location is ', location)
        if(location == ''):
            location = None;
        

        query = 'INSERT INTO book(ISBN, title, publisher, location) VALUES(%s, %s, %s, %s)'
        data = (ISBN, title, publisher, location)
        execute_query(db_connection, query, data)
        flash('New Book Added!')
        return redirect('/books');
    

@webapp.route('/books_search')
def bookSearch():
    db_connection = connect_to_database()
    search = request.args.get('filterLocation')
    print("arg is ", search)
    query = 'SELECT publisherID, companyName FROM publisher'
    res1 = execute_query(db_connection, query).fetchall();
    query2 = 'SELECT facilityID, branch FROM facility'
    res2 = execute_query(db_connection, query2).fetchall();
    if(search == ''):
        query3 = 'SELECT ISBN, title, companyName, branch FROM book JOIN publisher ON publisher.publisherID = book.publisher LEFT JOIN facility ON facility.facilityID = book.location WHERE book.location IS NULL'
    elif(search == '*'):
        query3 = 'SELECT ISBN, title, companyName, branch FROM book JOIN publisher ON publisher.publisherID = book.publisher LEFT JOIN facility ON facility.facilityID = book.location' 
    else:
        query3 = 'SELECT ISBN, title, companyName, branch FROM book JOIN publisher ON publisher.publisherID = book.publisher LEFT JOIN facility ON facility.facilityID = book.location WHERE book.location = %s' % (search)
    res3 = execute_query(db_connection, query3).fetchall();

    return render_template('books.html', publishers = res1, locations = res2, books = res3)


@webapp.route('/publishers', methods=['POST', 'GET'])
def viewPublishers():
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT publisherID, companyName, owner, city, state FROM publisher'
        res1 = execute_query(db_connection, query).fetchall();

        return render_template('publishers.html', publishers = res1)
    elif request.method == 'POST':
        companyName = request.form['companyName']
        owner = request.form['owner']
        city = request.form['city']
        state = request.form['state']

        query = 'INSERT INTO publisher(companyName, owner, city, state) VALUES(%s, %s, %s, %s)'
        data = (companyName, owner, city, state)
        execute_query(db_connection, query, data)
        flash('New Publisher Added!')
        return redirect('/publishers');
    
    
@webapp.route('/authors', methods=['POST', 'GET'])
def viewAuthors():
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT authorID, firstName, lastName, homeCity, homeState FROM author'
        res1 = execute_query(db_connection, query).fetchall();

        return render_template('authors.html', authors = res1)
    elif request.method == 'POST':
        firstName = request.form['fname']
        lastName = request.form['lname']
        homeCity = request.form['hcity']
        homeState= request.form['hstate']

        query = 'INSERT INTO author(firstName, lastName, homeCity, homeState) VALUES(%s, %s, %s, %s)'
        data = (firstName, lastName, homeCity, homeState)
        execute_query(db_connection, query, data)
        flash('New Author Added!')
        return redirect('/authors');
    

@webapp.route('/facilities', methods=['POST', 'GET'])
def viewFacilities():
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT facilityID, branch, streetAddress, city, state, capacity FROM facility'
        res1 = execute_query(db_connection, query).fetchall();

        return render_template('facilities.html', facilities = res1)
    elif request.method == 'POST':
        branch = request.form['branch']
        streetAddress = request.form['streetAddress']
        city = request.form['city']
        state = request.form['state']
        capacity = request.form['capacity']

        query = 'INSERT INTO facility(branch, streetAddress, city, state, capacity) VALUES(%s, %s, %s, %s, %s)'
        data = (branch, streetAddress, city, state, capacity)
        execute_query(db_connection, query, data)
        flash('New Facility Added!')
        return redirect('/facilities');
    
    
@webapp.route('/customers', methods=['POST', 'GET'])
def viewCustomers():
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT customerID, firstName, lastName, streetAddress, city, state, zip FROM customer'
        res1 = execute_query(db_connection, query).fetchall();

        return render_template('customers.html', customers = res1)
    elif request.method == 'POST':
        firstName = request.form['firstName']
        lastName = request.form['lastName']
        streetAddress = request.form['streetAddress']
        city = request.form['city']
        state = request.form['state']
        zipc = request.form['zip']

        query = 'INSERT INTO customer(firstName, lastName, streetAddress, city, state, zip) VALUES(%s, %s, %s, %s, %s, %s)'
        data = (firstName, lastName, streetAddress, city, state, zipc)
        execute_query(db_connection, query, data)
        flash('New Customer Added!')
        return redirect('/customers');
    
    
@webapp.route('/loans', methods=['POST', 'GET'])
def viewLoans():
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT ISBN, title FROM book'
        res1 = execute_query(db_connection, query).fetchall();
        query2 = 'SELECT customerID, firstName, lastName FROM customer'
        res2 = execute_query(db_connection, query2).fetchall();
        query3 = 'SELECT loanID, title, lastName, firstName, loanDate, dueDate FROM loan JOIN book ON book.ISBN = loan.bookID JOIN customer ON customer.customerID = loan.customerID'
        res3 = execute_query(db_connection, query3).fetchall();

        return render_template('loans.html', books = res1, customers = res2, loans = res3)
    elif request.method == 'POST':
        bookID = request.form['bookID']
        customerID = request.form['customerID']

        query = 'INSERT INTO loan(bookID, customerID) VALUES(%s, %s)'
        data = (bookID, customerID)
        execute_query(db_connection, query, data)
        flash('New Loan Added!')
        return redirect('/loans');
    
    
@webapp.route('/book_authors', methods=['POST', 'GET'])
def viewBookAuthors():
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT ISBN, title FROM book'
        res1 = execute_query(db_connection, query).fetchall();
        query2 = 'SELECT authorID, firstName, lastName FROM author'
        res2 = execute_query(db_connection, query2).fetchall();
        query3 = 'SELECT creatorID, title, lastName, firstName FROM book_author JOIN book ON book.ISBN = book_author.bookID JOIN author ON author.authorID = book_author.authorID'
        res3 = execute_query(db_connection, query3).fetchall();

        return render_template('book_authors.html', books = res1, authors = res2, bookauthor = res3)
    elif request.method == 'POST':
        bookID = request.form['bookID']
        authorID = request.form['authorID']

        query = 'INSERT INTO book_author(bookID, authorID) VALUES(%s, %s)'
        data = (bookID, authorID)
        execute_query(db_connection, query, data)
        flash('New Author Added To Book!')
        return redirect('/book_authors');

    
@webapp.route('/update_customer/<int:id>', methods=['POST', 'GET'])
def updateCustomers(id):
    db_connection = connect_to_database()
    if request.method == 'GET':
        query = 'SELECT customerID, firstName, lastName, streetAddress, city, state, zip FROM customer WHERE customerID=%s' % (id)
        res1 = execute_query(db_connection, query).fetchone();

        return render_template('update_customer.html', customer = res1)
    elif request.method == 'POST':
        cID = request.form['customerID']
        fName = request.form['firstName']
        lName = request.form['lastName']
        sAddress = request.form['streetAddress']
        c = request.form['city']
        st = request.form['state']
        zipc = request.form['zip']

        query = 'UPDATE customer SET firstName = %s, lastName = %s, streetAddress = %s, city = %s, state = %s, zip = %s WHERE customerID = %s'
        data = (fName, lName, sAddress, c, st, zipc, cID)
        execute_query(db_connection, query, data)
        flash('Customer Has Been Updated!')
        return redirect('/customers');
    

@webapp.route('/delete_customer/<int:id>')
def deleteCustomer(id):
    db_connection = connect_to_database()
    query = 'DELETE FROM customer WHERE customerID = %s'
    data = (id, ) 
    
    result = execute_query(db_connection, query, data)
    flash(str(result.rowcount) + " rows deleted")
    return redirect('/customers');


@webapp.route('/delete_book_author/<int:id>')
def deleteBookAuthor(id):
    db_connection = connect_to_database()
    query = 'DELETE FROM book_author WHERE creatorID = %s'
    data = (id, ) 
    
    result = execute_query(db_connection, query, data)
    flash(str(result.rowcount) + " rows deleted")
    return redirect('/book_authors');
