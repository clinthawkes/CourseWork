host = 'classmysql.engr.oregonstate.edu'
user = 'YOUR USER NAME'
passwd = 'YOUR PASSWORD'
db = 'cs340_hawkesc'
