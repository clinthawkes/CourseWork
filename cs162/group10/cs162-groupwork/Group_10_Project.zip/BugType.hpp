#ifndef BUGTYPE_HPP
#define BUGTYPE_HPP

enum BugType {ANT,BUG,CRITTER,EMPTY};

#endif
