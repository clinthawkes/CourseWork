/*******************************************************************************    
** Program Name:Matrix Calculator
** Author:      Clinton Hawkes
** Date:        04/02/2019
** Description: Header file for the readMatrix function 
*******************************************************************************/

#ifndef READMATRIX_HPP
#define READMATRIX_HPP

//readMatrix function prototype
void readMatrix(int**, int);

#endif
