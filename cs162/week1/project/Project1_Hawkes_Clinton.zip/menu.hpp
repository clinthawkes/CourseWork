/*******************************************************************************    
** Program Name:Langton's Ant   
** Name:        Clinton Hawkes
** Date:        04/08/2019
** Description: Header file for the menu functions. Implementation of these
                functions found in menu.cpp file.
*******************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

//function prototypes for the menu functions
int mainMenu();
int secondaryMenu();

#endif
