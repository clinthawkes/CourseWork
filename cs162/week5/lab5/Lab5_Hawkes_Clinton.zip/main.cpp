/**************************************************************************************************
** Program Name:Recursive Functions
** Author:      Clinton Hawkes
** Date:        05/01/2019
** Description: Main function for the program. This is only used to call the menu.
**************************************************************************************************/

#include "menu.hpp"

int main (){
    
    return menu();
}
