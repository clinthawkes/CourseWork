/**************************************************************************************************
** Program Name:
** Author:      Clinton Hawkes
** Date:        04/25/2019
** Description: 
**************************************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP


int mainMenu();
void peopleMenu();

#endif
